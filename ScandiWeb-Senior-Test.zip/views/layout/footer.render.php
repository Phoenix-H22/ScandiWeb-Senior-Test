<footer>
    <hr>
    <p>Scandiweb Senior Test <br> Done By:  <a href="https://ceo.phoenixtechs.tech/">Abdalrhman M. Alkady</a> <br> <a class="red" href="https://ceo.phoenixtechs.tech/uploads/2023/04/Abdalrhman_Alkady_Resume-1.pdf">Download CV</a></p>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>